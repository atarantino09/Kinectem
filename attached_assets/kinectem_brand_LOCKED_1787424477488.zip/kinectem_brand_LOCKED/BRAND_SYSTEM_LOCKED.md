# Kinectem — Brand System (LOCKED)

*Locked 22 August 2026. This supersedes the previous brand sheet.*

---

## Colour

**One ramp, two applications.** The icon is a *surface*; the K mark and "em" are *glyphs*. They share the same colours, but glyphs drop the dark shoulders — a shoulder inside a thin leaning stroke goes muddy at small sizes.

| | Stops |
|---|---|
| **SURFACE** — app icon, filled blocks | `#1C0A56` · `#8B22F0` · `#6A2BF8` · `#4A34F5` · `#2563EB` · `#0C2A8C` |
| **GLYPH** — K mark, "em", thin shapes | `#FF1F9E` · `#9B22E8` · `#7E22CE` · `#5B32E8` · `#2563EB` · `#3B82F6` |

### Palette

| Swatch | Name | Status |
|---|---|---|
| `#7E22CE` | Royal purple | unchanged |
| `#5B21B6` | Indigo | unchanged |
| `#4C1D95` | Deep violet | unchanged |
| `#1D4ED8` | Royal blue | unchanged |
| `#2563EB` | Bright blue | unchanged |
| `#0B1228` | Navy | unchanged |
| `#FF1F9E` | Magenta | **new** — accent only |
| `#1C0A56` | Ink violet | **new** — shoulder, surfaces only |
| `#0C2A8C` | Ink blue | **new** — shoulder, surfaces only |
| `#3A1470` | Shadow violet | **new** — shadows on light backgrounds |

---

## The seven rules

1. **One axis.** Every gradient runs 135°, top-left to bottom-right. Magenta at the origin, blue exits.
2. **Magenta is an accent, never a stop.** Max ~12% of any surface, always at the leading corner or the tip of a glyph.
3. **Shoulders are surfaces-only.** `#1C0A56` and `#0C2A8C` give the icon its depth. They never touch a glyph.
4. **Small objects get a compressed slice, not a shortened ramp.** "em" and the favicon use 0–58% of the glyph ramp, which keeps them violet-family instead of drifting blue.
5. **Shading is strong on the icon, light on the lockup.** The K mark is a glyph, not a surface — a heavy shadow behind it reads as a print artefact at header size. The wordmark gets no shading at all.
6. **Shadows on light backgrounds are violet-tinted** (`#3A1470`), never gray. Gray goes muddy against purple.
7. **Lockup spacing is fixed by ratio, not pixels.** It holds at any size.

---

## Lockup spacing

Derived by measuring the live app header. These three ratios are the standard:

- gap ÷ K-mark height = **0.176**
- K-mark height ÷ cap height = **1.619**
- **K-mark top is flush with the wordmark cap top** — the K descends below the baseline, it is *not* vertically centred on the wordmark

At the master size (K-mark height 217px) that resolves to a 38px gap.

---

## App icon

The K is **optically centred**: shifted `+51x / −60y` from the previous source file. Horizontal position splits 0.55 bounding-box-centre / 0.45 mass-centre — the thin upper arm stretches the bounding box rightward while carrying little visual weight, so pure geometric centring reads left-heavy. Vertically it then lifts 1.2%, because a letterform at true geometric centre reads as sitting low.

Final margins: **L313 R286 T280 B304**.

Shading is two layers: an ambient halo (0.46 strength, 70px blur) that darkens the gradient around the K so the white reads brighter, plus a contact shadow (0.80, 18px blur, offset +6x/+13y) that gives it a surface to sit on.

---

## Files

```
FINAL/
  kinectem_icon_master_1024.png
  kinectem_kmark_gradient.png · _black.png · _white.png
  kinectem_logo_horizontal_light.png · _dark.png
  kinectem_logo_horizontal_light_noshadow.png · _dark_noshadow.png
  icon_suite/     iOS · Android · web · macOS · maskable  (41 files)
  favicon/        .ico + PNG set + apple-touch-icon        (8 files)
  kmark_sizes/    gradient / black / white at 7 sizes      (21 files)
  lockup_sizes/   4 cuts at 5 widths                       (20 files)
```

**Shadow vs no-shadow.** The shadowed lockups are for the white web header and the navy app chrome. Both keep transparent backgrounds, so the shadow travels with the mark — on a photo or a mid-tone brand colour it will look wrong. Use the `_noshadow` cuts there.

---

## Unchanged

Poppins Bold wordmark · 15° K lean · K and wordmark geometry · all six original brand hexes. This was a colour and spacing change only. No letterform was redrawn.

---

## Regenerate, don't patch

The K's position inside the icon moved. Anything with the old icon baked in has to be rebuilt from this master rather than colour-shifted:

- the previous 81-file icon suite
- the favicon set
- `partnership_post_v3.py`
- the Feature Friday Instagram template
- the showcase post desktop mockups
- any deck or PDF carrying the old app icon

The Quick-Yes, FAQ Friday and vs-carousel templates use the **horizontal lockup**, not the icon — those need the new lockup PNG swapped in, but their layout rules (50px tall at 60,60) are unaffected.

---

## Vector source

`vector/` holds the editable SVG masters, rebuilt from the original K geometry recovered from the May build:

```
M 0 0 L 14 0 L 14 35 L 38 0 L 56 0 L 30 36 L 58 80 L 39 80 L 18 47 L 14 53 L 14 80 L 0 80 Z
```

with `skewX(-15)` — the 15° forward lean.

Two things are **baked into the coordinates** rather than applied as transforms: the skew on the K, and the position/scale of every wordmark glyph. Nested transforms would put each gradient's user space inside its own group, which restarts the ramp on every letter. Baking also means these import cleanly into Figma and Illustrator, and the SVGs carry no font dependency — the wordmark is outlines, not live text.

**One caveat on the SVG stop colours.** The raster masters apply a saturation and contrast pass over the composite, which SVG has no equivalent for. The stops in the SVGs are therefore the spec colours *with that pass already folded in*, so the rendered result matches the approved PNG. The spec colours listed above remain the definition; the SVG hexes are a rendering detail. The shading also differs slightly — SVG `feDropShadow` can't exactly reproduce the two-layer numpy halo, so the vector version's ambient falloff is a touch softer. The PNG masters remain authoritative for anything pixel-critical.

### Corrected terminology

An earlier version of this spec described the lockup ratio as "K-mark height ÷ cap height = 1.619". That measurement was taken from the top of the tallest glyph — the dot on the *i*, which in Poppins Bold rises to 801 units against a cap height of 705 — down to the baseline. Against **true cap height** the ratio is **1.858**. The alignment rule is likewise "K-mark top flush with the top of the *i* dot", not the cap top. The rendered geometry never changed; only the label was wrong.

Wordmark is Poppins Bold with **−0.016em** tracking.

---

## Still outstanding

- **Updated brand sheet** to replace the existing one
