# Kinectem — Locked Brand Package

Locked 22 August 2026. Supersedes all previous brand exports.

## Read these first

| File | What it is |
|---|---|
| `kinectem_brand_sheet_2026.png` / `.pdf` | The brand sheet — replaces the old one |
| `BRAND_SYSTEM_LOCKED.md` | Full spec: colour, rules, geometry, centring maths |
| `REPLIT_HANDOFF.md` | Implementation guide for the web app |

## Master files

| File | Use |
|---|---|
| `kinectem_icon_master_1024.png` | The app logo. Master for every icon export. |
| `kinectem_logo_horizontal_light/dark.png` | Primary lockup |
| `kinectem_logo_horizontal_*_noshadow.png` | For photos and mid-tone backgrounds |
| `kinectem_logo_horizontal_mono_black/white.png` | Single-colour |
| `kinectem_logo_stacked_*.png` | Square spaces, social profiles, hero |
| `kinectem_kmark_gradient/black/white.png` | K alone — avatars, watermarks |

## Folders

| Folder | Files | Contents |
|---|---|---|
| `vector/` | 16 | Editable SVG masters. Outlined wordmark, no font dependency. |
| `icon_suite/` | 40 | iOS 13 · Android 7 · web 11 · macOS 7 · maskable · manifest |
| `favicon/` | 8 | Multi-res `.ico`, PNG 16–512, apple-touch-icon |
| `kmark_sizes/` | 21 | K mark, 3 fills x 7 sizes |
| `lockup_sizes/` | 40 | Horizontal + stacked, 4 cuts x 5 widths |
| `social/` | 5 | Open Graph cards, profile avatars, LinkedIn banner |

## Deploying it

`REPLIT_HANDOFF.md` opens with the instruction: **replace every logo across
kinectem.com and app.kinectem.com, consistently, on desktop and mobile.** It
contains a placement inventory covering every surface a logo appears on, a
mobile section, and a QA checklist. Work that document top to bottom.

## The short version

One gradient ramp, two applications. The app icon is a **surface** and uses the
full ramp including dark shoulders. The K mark and the "em" are **glyphs** and
use the same colours with the shoulders removed — a shoulder inside a thin
leaning stroke goes muddy at small sizes.

Every gradient runs 135°, top-left to bottom-right, magenta at the origin.
Magenta is an accent, never a stop.

## Regenerate, don't patch

The K's position inside the app icon moved. Anything with the old icon baked in
must be rebuilt from `kinectem_icon_master_1024.png`, not colour-shifted:
the previous 81-file icon suite, the favicon set, `partnership_post_v3.py`,
the Feature Friday template, and the showcase post mockups.

Templates that use the *lockup* rather than the icon — Quick-Yes, FAQ Friday,
vs-carousels — need only the new PNG swapped in. Their layout rules
(50px tall at 60,60) are unaffected.
